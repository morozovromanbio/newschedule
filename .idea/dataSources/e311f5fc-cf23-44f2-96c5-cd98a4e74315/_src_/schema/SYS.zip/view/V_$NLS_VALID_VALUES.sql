create view V_$NLS_VALID_VALUES as
select "PARAMETER","VALUE","ISDEPRECATED","CON_ID" from v$nls_valid_values
