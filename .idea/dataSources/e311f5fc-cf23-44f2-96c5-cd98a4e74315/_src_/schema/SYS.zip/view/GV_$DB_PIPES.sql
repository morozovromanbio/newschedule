create view GV_$DB_PIPES as
select "INST_ID","OWNERID","NAME","TYPE","PIPE_SIZE","CON_ID","CON_NAME" from gv$db_pipes
