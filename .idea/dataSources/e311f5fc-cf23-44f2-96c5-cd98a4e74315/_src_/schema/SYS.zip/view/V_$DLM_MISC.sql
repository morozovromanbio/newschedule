create view V_$DLM_MISC as
select "STATISTIC#","NAME","VALUE","CON_ID" from v$dlm_misc
