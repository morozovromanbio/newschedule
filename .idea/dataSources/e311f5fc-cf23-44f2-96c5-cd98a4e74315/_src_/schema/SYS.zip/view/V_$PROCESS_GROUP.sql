create view V_$PROCESS_GROUP as
select "INDX","NAME","PID","CON_ID" from v$process_group
