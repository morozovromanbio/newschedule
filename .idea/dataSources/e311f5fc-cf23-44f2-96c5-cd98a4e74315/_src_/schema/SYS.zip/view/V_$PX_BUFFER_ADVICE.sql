create view V_$PX_BUFFER_ADVICE as
select "STATISTIC","VALUE","CON_ID" from v$px_buffer_advice
