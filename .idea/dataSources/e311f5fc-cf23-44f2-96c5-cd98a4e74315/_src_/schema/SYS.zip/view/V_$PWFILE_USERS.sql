create view V_$PWFILE_USERS as
select "USERNAME","SYSDBA","SYSOPER","SYSASM","SYSBACKUP","SYSDG","SYSKM","CON_ID" from v$pwfile_users
