create view V_$MYSTAT as
select "SID","STATISTIC#","VALUE","CON_ID" from v$mystat
