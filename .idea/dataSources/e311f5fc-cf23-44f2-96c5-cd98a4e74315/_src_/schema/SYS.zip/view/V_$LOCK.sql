create view V_$LOCK as
select "ADDR","KADDR","SID","TYPE","ID1","ID2","LMODE","REQUEST","CTIME","BLOCK","CON_ID" from v$lock
