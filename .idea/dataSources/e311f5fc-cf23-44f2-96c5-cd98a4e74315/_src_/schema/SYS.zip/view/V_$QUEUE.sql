create view V_$QUEUE as
select "PADDR","TYPE","QUEUED","WAIT","TOTALQ","CON_ID" from v$queue
