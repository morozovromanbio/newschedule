create view GV_$OBSOLETE_PARAMETER as
select "INST_ID","NAME","ISSPECIFIED","CON_ID" from gv$obsolete_parameter
