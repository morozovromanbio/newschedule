create view GV_$MUTEX_SLEEP as
select "INST_ID","MUTEX_TYPE","LOCATION","SLEEPS","WAIT_TIME","CON_ID" from gv$mutex_sleep
