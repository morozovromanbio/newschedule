create view V_$FILE_HISTOGRAM as
select "FILE#","SINGLEBLKRDTIM_MILLI","SINGLEBLKRDS","CON_ID" from v$file_histogram
