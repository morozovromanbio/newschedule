create view V_$PARALLEL_DEGREE_LIMIT_MTH as
select "NAME","CON_ID" from v$parallel_degree_limit_mth
