create view V_$PX_PROCESS_TRACE as
select "TIME_STAMP","PID","SPID","SLVID","PNAME","SID","QC_INST_ID","QCSID","SERVER_SET","SERVER#","COMP","FILENAME","LINE","FUNC","TRACE","CON_ID" from v$px_process_trace
