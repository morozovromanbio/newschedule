create view GV_$PGASTAT as
select "INST_ID","NAME","VALUE","UNIT","CON_ID" from gv$pgastat
