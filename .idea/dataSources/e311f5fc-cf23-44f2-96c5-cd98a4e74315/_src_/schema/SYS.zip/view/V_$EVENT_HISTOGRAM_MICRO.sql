create view V_$EVENT_HISTOGRAM_MICRO as
select "EVENT#","EVENT","WAIT_TIME_FORMAT","WAIT_TIME_MICRO","WAIT_COUNT","LAST_UPDATE_TIME","CON_ID" from v$event_histogram_micro
