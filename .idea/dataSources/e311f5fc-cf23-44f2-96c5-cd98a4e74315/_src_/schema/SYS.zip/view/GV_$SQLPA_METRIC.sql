create view GV_$SQLPA_METRIC as
select "INST_ID","METRIC_NAME","CON_ID" from gv$sqlpa_metric
