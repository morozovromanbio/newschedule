create view V_$RMAN_CONFIGURATION as
select "CONF#","NAME","VALUE","CON_ID" from v$rman_configuration
