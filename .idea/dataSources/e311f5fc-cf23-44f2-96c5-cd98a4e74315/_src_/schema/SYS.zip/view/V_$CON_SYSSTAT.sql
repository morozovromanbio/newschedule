create view V_$CON_SYSSTAT as
select "STATISTIC#","NAME","CLASS","VALUE","STAT_ID","CON_ID" from v$con_sysstat
