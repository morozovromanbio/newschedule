create view V_$BGPROCESS as
select "PADDR","PSERIAL#","NAME","DESCRIPTION","ERROR","CON_ID" from v$bgprocess
