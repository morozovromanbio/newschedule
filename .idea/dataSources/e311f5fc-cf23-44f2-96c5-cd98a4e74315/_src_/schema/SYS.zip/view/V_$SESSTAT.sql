create view V_$SESSTAT as
select "SID","STATISTIC#","VALUE","CON_ID" from v$sesstat
