create view V_$MUTEX_SLEEP as
select "MUTEX_TYPE","LOCATION","SLEEPS","WAIT_TIME","CON_ID" from v$mutex_sleep
