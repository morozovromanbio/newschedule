create view V_$HS_SESSION as
select "HS_SESSION_ID","AGENT_ID","SID","DB_LINK","DB_LINK_OWNER","STARTTIME","CON_ID" from v$hs_session
