create view GV_$MYSTAT as
select "INST_ID","SID","STATISTIC#","VALUE","CON_ID" from gv$mystat
