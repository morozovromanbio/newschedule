create view V_$PARAMETER_VALID_VALUES as
select "NUM","NAME","ORDINAL","VALUE","ISDEFAULT","CON_ID" from v$parameter_valid_values
