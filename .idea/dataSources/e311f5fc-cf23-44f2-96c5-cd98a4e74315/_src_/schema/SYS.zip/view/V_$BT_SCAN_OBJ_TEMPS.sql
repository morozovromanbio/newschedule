create view V_$BT_SCAN_OBJ_TEMPS as
select "TS#","DATAOBJ#","SIZE_IN_BLKS","TEMPERATURE","POLICY","CACHED_IN_MEM","CON_ID" from v$bt_scan_obj_temps
