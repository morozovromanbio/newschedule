create view V_$STATNAME as
select "STATISTIC#","NAME","CLASS","STAT_ID","DISPLAY_NAME","CON_ID" from v$statname
