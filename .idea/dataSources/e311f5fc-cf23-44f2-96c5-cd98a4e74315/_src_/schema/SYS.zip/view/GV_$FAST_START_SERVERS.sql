create view GV_$FAST_START_SERVERS as
select "INST_ID","STATE","UNDOBLOCKSDONE","PID","XID","CON_ID" from gv$fast_start_servers
