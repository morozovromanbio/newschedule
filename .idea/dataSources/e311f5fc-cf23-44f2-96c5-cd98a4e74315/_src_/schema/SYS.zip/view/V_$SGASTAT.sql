create view V_$SGASTAT as
select "POOL","NAME","BYTES","CON_ID" from v$sgastat
