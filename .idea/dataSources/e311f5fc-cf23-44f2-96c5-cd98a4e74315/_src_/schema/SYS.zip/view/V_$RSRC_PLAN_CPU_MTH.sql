create view V_$RSRC_PLAN_CPU_MTH as
select "NAME","CON_ID" from v$rsrc_plan_cpu_mth
