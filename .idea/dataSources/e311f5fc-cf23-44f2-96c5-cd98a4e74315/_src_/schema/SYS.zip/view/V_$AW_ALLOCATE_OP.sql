create view V_$AW_ALLOCATE_OP as
select "NAME","LONGNAME","CON_ID" from v$aw_allocate_op
