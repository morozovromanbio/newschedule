create view GV_$OBJECT_DEPENDENCY as
select "INST_ID","FROM_ADDRESS","FROM_HASH","TO_OWNER","TO_NAME","TO_ADDRESS","TO_HASH","TO_TYPE","CON_ID" from gv$object_dependency
