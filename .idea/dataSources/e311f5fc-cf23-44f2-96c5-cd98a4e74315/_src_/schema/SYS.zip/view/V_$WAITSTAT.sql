create view V_$WAITSTAT as
select "CLASS","COUNT","TIME","CON_ID" from v$waitstat
