create view GV_$BT_SCAN_OBJ_TEMPS as
select "INST_ID","TS#","DATAOBJ#","SIZE_IN_BLKS","TEMPERATURE","POLICY","CACHED_IN_MEM","CON_ID" from gv$bt_scan_obj_temps
