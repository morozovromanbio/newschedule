create view V_$DATAGUARD_CONFIG as
select "DB_UNIQUE_NAME","PARENT_DBUN","DEST_ROLE","CURRENT_SCN","CON_ID" from v$dataguard_config
