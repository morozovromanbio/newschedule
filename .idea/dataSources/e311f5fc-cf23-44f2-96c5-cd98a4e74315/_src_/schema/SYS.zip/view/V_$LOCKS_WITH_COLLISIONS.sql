create view V_$LOCKS_WITH_COLLISIONS as
select "LOCK_ELEMENT_ADDR","CON_ID" from v$locks_with_collisions
