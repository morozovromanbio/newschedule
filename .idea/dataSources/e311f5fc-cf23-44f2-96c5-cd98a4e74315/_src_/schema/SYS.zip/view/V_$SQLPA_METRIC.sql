create view V_$SQLPA_METRIC as
select "METRIC_NAME","CON_ID" from v$sqlpa_metric
