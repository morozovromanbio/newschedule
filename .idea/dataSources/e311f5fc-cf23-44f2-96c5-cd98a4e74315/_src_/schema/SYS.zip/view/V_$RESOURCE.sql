create view V_$RESOURCE as
select "ADDR","TYPE","ID1","ID2","CON_ID" from v$resource
