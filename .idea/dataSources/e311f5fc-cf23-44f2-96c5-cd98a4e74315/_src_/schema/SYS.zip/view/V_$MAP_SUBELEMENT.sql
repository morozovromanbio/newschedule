create view V_$MAP_SUBELEMENT as
select "CHILD_IDX","PARENT_IDX","SUB_NUM","SUB_SIZE","ELEM_OFFSET","SUB_FLAGS","CON_ID" from v$map_subelement
