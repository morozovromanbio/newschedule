create view V_$VERSION as
select "BANNER","CON_ID" from v$version
