create view GV_$LOCK as
select "INST_ID","ADDR","KADDR","SID","TYPE","ID1","ID2","LMODE","REQUEST","CTIME","BLOCK","CON_ID" from gv$lock
