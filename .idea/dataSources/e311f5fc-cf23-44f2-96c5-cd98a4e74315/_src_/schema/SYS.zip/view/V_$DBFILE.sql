create view V_$DBFILE as
select "FILE#","NAME","CON_ID" from v$dbfile
