create view V_$SGA as
select "NAME","VALUE","CON_ID" from v$sga
