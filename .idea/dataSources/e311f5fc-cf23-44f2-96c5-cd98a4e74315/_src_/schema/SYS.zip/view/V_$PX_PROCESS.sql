create view V_$PX_PROCESS as
select "SERVER_NAME","STATUS","PID","SPID","SID","SERIAL#","IS_GV","CON_ID" from v$px_process
