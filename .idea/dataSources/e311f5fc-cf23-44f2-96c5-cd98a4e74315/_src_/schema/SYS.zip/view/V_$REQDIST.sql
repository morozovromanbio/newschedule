create view V_$REQDIST as
select "BUCKET","COUNT","CON_ID" from v$reqdist
