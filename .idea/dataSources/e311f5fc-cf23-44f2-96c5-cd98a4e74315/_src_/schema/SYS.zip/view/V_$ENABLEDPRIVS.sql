create view V_$ENABLEDPRIVS as
select "PRIV_NUMBER","CON_ID" from v$enabledprivs
