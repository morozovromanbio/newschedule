create view V_$OPTION as
select "PARAMETER","VALUE","CON_ID" from v$option
