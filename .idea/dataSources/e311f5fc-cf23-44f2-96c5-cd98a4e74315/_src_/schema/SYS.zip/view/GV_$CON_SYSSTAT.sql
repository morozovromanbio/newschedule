create view GV_$CON_SYSSTAT as
select "INST_ID","STATISTIC#","NAME","CLASS","VALUE","STAT_ID","CON_ID" from gv$con_sysstat
