create view GV_$SGA as
select "INST_ID","NAME","VALUE","CON_ID" from gv$sga
