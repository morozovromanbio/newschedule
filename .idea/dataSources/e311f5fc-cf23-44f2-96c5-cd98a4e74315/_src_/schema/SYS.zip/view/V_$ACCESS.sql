create view V_$ACCESS as
select "SID","OWNER","OBJECT","TYPE","CON_ID" from v$access
