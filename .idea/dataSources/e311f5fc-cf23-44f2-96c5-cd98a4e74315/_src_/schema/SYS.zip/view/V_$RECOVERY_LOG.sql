create view V_$RECOVERY_LOG as
select "THREAD#","SEQUENCE#","TIME","ARCHIVE_NAME","CON_ID" from v$recovery_log
