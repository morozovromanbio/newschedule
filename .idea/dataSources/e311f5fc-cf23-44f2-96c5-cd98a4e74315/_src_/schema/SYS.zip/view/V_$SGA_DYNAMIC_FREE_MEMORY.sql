create view V_$SGA_DYNAMIC_FREE_MEMORY as
select "CURRENT_SIZE","CON_ID" from v$sga_dynamic_free_memory
