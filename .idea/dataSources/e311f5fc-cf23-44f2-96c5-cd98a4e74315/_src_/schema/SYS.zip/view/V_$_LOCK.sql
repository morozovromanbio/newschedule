create view V_$_LOCK as
select "LADDR","KADDR","SADDR","RADDR","LMODE","REQUEST","CTIME","BLOCK","CON_ID" from v$_lock
