create view V_$BACKUP_DEVICE as
select "DEVICE_TYPE","DEVICE_NAME","CON_ID" from v$backup_device
