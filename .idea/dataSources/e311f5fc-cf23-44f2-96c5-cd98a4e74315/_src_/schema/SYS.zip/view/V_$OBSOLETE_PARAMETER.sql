create view V_$OBSOLETE_PARAMETER as
select "NAME","ISSPECIFIED","CON_ID" from v$obsolete_parameter
