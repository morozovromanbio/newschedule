create view V_$LOCK_TYPE as
select "TYPE","NAME","ID1_TAG","ID2_TAG","IS_USER","IS_RECYCLE","DESCRIPTION","CON_ID" from v$lock_type
