create view GV_$LOGHIST as
select "INST_ID","THREAD#","SEQUENCE#","FIRST_CHANGE#","FIRST_TIME","SWITCH_CHANGE#","CON_ID" from gv$loghist
